export default SimpleMenu;
export type MenuItem = {
    /**
     * - Texte de l'élément de menu.
     */
    text: string;
    /**
     * - Fonction à exécuter lors du clic sur l'élément de menu.
     */
    callback: Function;
    /**
     * - Définit si le menu doit se fermer après le clic sur cet élément.
     */
    hide?: boolean | undefined;
    /**
     * - Utiliser un lien plutot qu'un bouton
     */
    link?: boolean | undefined;
    /**
     * - Classe CSS à appliquer à l'élément de menu.
     */
    className?: string | undefined;
};
/**
 * @typedef {Object} MenuItem
 * @property {string} text - Texte de l'élément de menu.
 * @property {Function} callback - Fonction à exécuter lors du clic sur l'élément de menu.
 * @property {boolean} [hide=true] - Définit si le menu doit se fermer après le clic sur cet élément.
 * @property {boolean} [link=false] - Utiliser un lien plutot qu'un bouton
 * @property {string} [className] - Classe CSS à appliquer à l'élément de menu.
 */
/** A simple menu to display on a map
 * @extends {ol.control.Control}
 */
declare class SimpleMenu {
    /**
     * Initialize simple menu
     * @param {Object} options Control options
     *
     */
    constructor(options?: any);
    /**
     * Set menu items
     * @param {Array<MenuItem>} items Array of menu items
     */
    setMenu(items?: Array<MenuItem>): void;
    /**
     * Display menu at pixel
     * @param {ol.Pixel} pixel Pixel position
     */
    show(pixel: ol.Pixel): void;
    /**
     * Hide menu
     */
    hide(): void;
}
//# sourceMappingURL=SimpleMenu.d.ts.map