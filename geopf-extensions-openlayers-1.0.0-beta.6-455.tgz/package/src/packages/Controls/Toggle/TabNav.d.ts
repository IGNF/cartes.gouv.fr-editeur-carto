export default TabNav;
/**
 * @classdesc
 * Classe gérant une navigation tertiaire avec onglets.
 *
 * @alias TabNav
 * @module TabNav
 * @extends {Control}
 */
declare class TabNav extends Control {
    /**
     * Constructeur du TabNav.
     * @constructor
     * @param {TabNavOptions} options Options du constructeur
     */
    constructor(options?: TabNavOptions);
    navigationList: Element | null;
    /**
     * @param {TabNavOptions} options Options de construction
     */
    _initialize(options: TabNavOptions): void;
    tabNavClass: string | undefined;
    selectors: {
        NAVIGATION: string;
        NAVIGATION_LIST: string;
        NAVIGATION_ITEM: string;
        NAVIGATION_LINK: string;
        CURRENT_LINK: string;
        OPEN_TAB: string;
        CLOSE_TAB: string;
    } | undefined;
    contentContainer: HTMLElement | undefined;
    setMap(map: any): void;
    /**
     * Crée le conteneur principal de la navigation.
     * @protected
     * @param {TabNavOptions} options Options de construction
     * @returns {HTMLElement} Élément div de navigation
     */
    protected _initContainer(options: TabNavOptions): HTMLElement;
    /**
     * @param {TabNavOptions} options Options du constructeur
     */
    _initEvents(options: TabNavOptions): void;
    /**
     * Ajoute plusieurs items à la navigation.
     * @param {Array<TabNavItem>} items Liste des items à ajouter
     */
    addItems(items: Array<TabNavItem>): void;
    /**
     * Ajoute un item à la navigation.
     * @param {TabNavItem} item Item à ajouter
     */
    addItem(item: TabNavItem): void;
    /**
     * Booléen retournant le nombre d'item dans la navigation
     * @returns {Boolean} Vrai si contient des éléments
     */
    hasNavItem(): boolean;
    /**
     * Gère le clic sur un onglet.
     * @private
     * @param {PointerEvent} e Événement de click sur le bouton
     */
    private _handleClick;
    /**
     * Retourne le lien actuellement sélectionné.
     * @returns {HTMLButtonElement|null} Bouton actuellement sélectionné
     */
    getCurrentLink(): HTMLButtonElement | null;
    /**
     * Définit le lien courant et gère l'affichage du contenu.
     * @param {HTMLButtonElement} link Bouton à activer
     */
    setCurrentLink(link: HTMLButtonElement): void;
    /**
     * Vérifie si la navigation contient des items.
     * @returns {Boolean} True si au moins un item existe
     */
    hasItems(): boolean;
    /**
     * Retourne l'élément principal de la navigation.
     * @returns {HTMLElement} Élément div de navigation
     */
    getElement(): HTMLElement;
    /**
     * Affiche la navigation.
     */
    show(): void;
    /**
     * Masque la navigation.
     */
    hide(): void;
    /**
     * Affiche un item.
     * @param {HTMLDivElement} item Item à afficher
     */
    showItem(item: HTMLDivElement): void;
    /**
     * Masque un item.
     * @param {HTMLDivElement} item Item à masquer
     */
    hideItem(item: HTMLDivElement): void;
    /**
     * Sélectionne le premier onglet.
     */
    selectFirst(): void;
    /**
     * Supprime tous les items de la navigation.
     */
    clear(): void;
}
import Control from "../Control";
//# sourceMappingURL=TabNav.d.ts.map