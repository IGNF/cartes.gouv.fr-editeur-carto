export default Dialog;
/**
 * @classdesc
 * Classe gérant un dialog HTML avec titre, icône et contenu.
 *
 * @alias Dialog
 * @module Dialog
 */
declare class Dialog extends ControlExtended {
    /**
     * Constructeur du Dialog.
     * @constructor
     * @param {DialogOptions} options Options du constructeur
     */
    constructor(options?: DialogOptions);
    element: HTMLDialogElement;
    dialogTitle: Element;
    dialogIcon: Element;
    dialogContent: Element;
    onOpenCallback: Function | undefined;
    onCloseCallback: Function | undefined;
    setMap(map: any): void;
    /**
     * Initialise le contrôle Toggle (appelé par le constructeur).
     * @protected
     * @param {DialogOptions} options Options du constructeur
     */
    protected _initialize(options: DialogOptions): void;
    dialogClass: string | undefined;
    selectors: {
        TITLE: string;
        BUTTON_GROUP: string;
        BUTTONS: string;
        BTN_CLOSE: string;
        ICON: string;
        CONTENT: string;
        OPEN_EVENT: string;
        CHANGE_CONTENT: string;
        CLOSE_EVENT: string;
    } | undefined;
    tabNav: TabNav | null | undefined;
    /**
     * Crée le conteneur principal du dialog.
     * @private
     * @param {DialogOptions} options Options de construction
     * @returns {HTMLDialogElement} Dialog HTML avec le contenu
     */
    private _initContainer;
    closeBtn: HTMLButtonElement | undefined;
    /**
     * Ajoute les écouteurs d'événements sur les éléments du contrôle.
     * @protected
     * @param {DialogOptions} options Options du constructeur
     */
    protected _initEvents(options: DialogOptions): void;
    /**
     * Définit la position du panneau (droite ou gauche).
     * @param {String} position Position du panneau ("left" ou "right")
     */
    setPos(position: string): void;
    /**
     * Définit la taille du panneau (sm ou md).
     * @param {String} size Taille du panneau (sm ou md)
     */
    setSize(size: string): void;
    /**
     * Fonction utilitaire pour paramétrer facilement le dialog.
     *
     * @param {Object} options Élements du dialog
     * @param {String} options.title Titre
     * @param {String} options.icon Icône
     * @param {String|Element} options.content Contenu du dialog.
     */
    setContent(options?: {
        title: string;
        icon: string;
        content: string | Element;
    }): void;
    /**
     * Fonction utilitaire pour paramétrer facilement l'icône.
     * @param {String} icon Icône
     * @param {String} [title] Titre
     */
    setIcon(icon: string, title?: string): void;
    iconClass: string | undefined;
    /**
     * Retourne l'élément principal du contrôle.
     * @returns {HTMLDialogElement} Élément HTML du contrôle (balise dialog)
     */
    getElement(): HTMLDialogElement;
    /**
     * Retourne le titre du dialog (contenu).
     * @returns {String} Contenu du titre
     */
    getDialogTitle(): string;
    /**
     * Ajoute un titre au dialog.
     * @param {String} title Titre à remplacer
     */
    setDialogTitle(title: string): void;
    /**
     * Retourne le contenu du dialog.
     *
     * @returns {Element} Contenu du dialog
     */
    getDialogContent(): Element;
    /**
     * Ajoute un contenu au dialog.
     *
     * @param {Element|String|null} content Contenu du dialog
     * @param {Boolean} [clear=true] Si vrai, efface le contenu du dialog
     */
    setDialogContent(content: Element | string | null, clear?: boolean): void;
    /**
     * Sélectionne le premier élément du dialog correspondant
     * au sélecteur CSS.
     *
     * @param {String} selector Sélecteur CSS.
     * @returns {Element} Premier élément correspondant au sélecteur.
     */
    querySelector(selector: string): Element;
    /**
     * Sélectionne tous les éléments du dialog correspondant
     * au selecteur CSS.
     *
     * @param {String} selector Sélecteur CSS
     * @returns {NodeList} Liste des élements correspondant au sélecteur
     */
    querySelectorAll(selector: string): NodeList;
    /**
     * Ouvre le dialog.
     */
    show(): void;
    /**
     * Ferme le dialog.
     */
    close(): void;
    /**
     * Vérifie si le dialog est ouvert.
     * @returns {Boolean} True si le dialog est ouvert
     */
    isOpen(): boolean;
    /**
     * Ajoute une navigation tertiaire au dialog.
     * @param {Array<TabNavItem>} items Liste des items de navigation
     * @param {String} [label] Attribut aria label de la navigation tertiaire
     */
    setTabNav(items: Array<TabNavItem>, label?: string): void;
    /**
     * Retourne l'instance de la navigation tertiaire.
     * @returns {TabNav|null} Instance de TabNav ou null
     */
    getTabNav(): TabNav | null;
    /**
     * Ajoute un item à la navigation tertiaire.
     * @param {TabNavItem} item Item à ajouter
     */
    addTabNavItem(item: TabNavItem): void;
    /**
     * Supprime tous les items de la navigation tertiaire.
     */
    clearTabNav(): void;
}
import ControlExtended from "../Control";
import TabNav from "./TabNav";
//# sourceMappingURL=Dialog.d.ts.map