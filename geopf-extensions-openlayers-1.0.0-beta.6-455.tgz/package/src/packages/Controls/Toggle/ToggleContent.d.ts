export default ToggleContent;
/**
 * @classdesc
 * Contrôle de base créant un toggle avec contenu.
 *
 * @alias ol.control.ToggleContent
 * @module ToggleContent
 */
declare class ToggleContent extends Toggle {
    /**
     * Constructeur du contrôle ToggleContent.
     * @constructor
     * @param {ToggleContentOptions} options Options du constructeur
     */
    constructor(options: ToggleContentOptions);
    /**
     * Initialise le contrôle ToggleInteraction (appelé par le constructeur).
     * @protected
     * @param {ToggleContentOptions} options Options du constructeur
     */
    protected _initialize(options: ToggleContentOptions): void;
    /**
     * Définit la position du panneau (droite ou gauche).
     * @param {String} position Position du panneau ("left" ou "right")
     */
    setDialogPosition(position: string): void;
    /**
     * Définit la taille du panneau (sm ou md).
     * @param {String} size Taille du panneau (sm ou md)
     */
    setDialogSize(size: string): void;
    /**
     * Ajoute les écouteurs d"événements sur les éléments du contrôle.
     * @protected
     * @param {ToggleContentOptions} options Options du constructeur
     */
    protected _initEvents(options: ToggleContentOptions): void;
    /**
     * Initialise le conteneur DOM principal du contrôle.
     * @protected
     * @param {ToggleContentOptions} options Options du constructeur
     */
    protected _initContainer(options: ToggleContentOptions): void;
    dialog: Dialog | undefined;
    /**
     * Fonction utilitaire pour paramétrer facilement le dialog.
     *
     * @param {Object} options Élements du dialog
     * @param {String} options.title Titre
     * @param {String} options.icon Icône
     * @param {String|Element} options.content Contenu du dialog.
     */
    setContent(options: {
        title: string;
        icon: string;
        content: string | Element;
    }): void;
    /**
     * Retourne le dialog associé au toggle
     * @returns {Dialog} Objet dialog
     */
    getDialog(): Dialog;
    /**
     * Retourne le titre du dialog (contenu).
     * @returns {String} Contenu du titre
     */
    getDialogTitle(): string;
    /**
     * Ajoute un titre au dialog.
     * @param {String} title Titre à remplacer
     */
    setDialogTitle(title: string): void;
    /**
     * Retourne le contenu du dialog.
     *
     * @returns {Element} Contenu de la modale
     */
    getDialogContent(): Element;
    /**
     * Ajoute un contenu au dialog.
     *
     * @param {Element|String|null} content Contenu du dialog
     */
    setDialogContent(content: Element | string | null): void;
    /**
     * Sélectionne le premier élément du dialog correspondant
     * au sélecteur CSS.
     *
     * @param {String} selector Sélecteur CSS.
     * @returns {Element} Premier élément correspondant au sélecteur.
     */
    querySelector(selector: string): Element;
    /**
     * Sélectionne tous les éléments du dialog correspondant
     * au selecteur CSS.
     *
     * @param {String} selector Sélecteur CSS
     * @returns {NodeList} Liste des élements correspondant au sélecteur
     */
    querySelectorAll(selector: string): NodeList;
}
import Toggle from "./Toggle";
import Dialog from "./Dialog";
//# sourceMappingURL=ToggleContent.d.ts.map