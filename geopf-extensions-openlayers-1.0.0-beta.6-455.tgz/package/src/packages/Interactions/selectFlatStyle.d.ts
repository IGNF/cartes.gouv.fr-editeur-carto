export const defaultFlatStyle: {};
export function selectStyle(type: any, featureType: any, iconSrc: any): any;
/** Get all points in coordinates
 * @param {Feature|Array<coordinate>} coords Coordinates or feature
 * @returns {Array<coordinate>} Flat coordinates array
 * @private
 */
export function getFlatCoordinates(coords: Feature | Array<coordinate>): Array<coordinate>;
import Feature from "ol/Feature";
//# sourceMappingURL=selectFlatStyle.d.ts.map