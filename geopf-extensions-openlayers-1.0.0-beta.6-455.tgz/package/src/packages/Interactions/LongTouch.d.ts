export default LongTouch;
/** Interaction to handle longtouch events
 * @constructor
 * @extends {ol_interaction_Interaction}
 * @param {Object} options Interaction options
 * 	@param {function | undefined} options.handleLongTouchEvent Function handling "longtouch" events, it will receive a mapBrowserEvent. Or listen to the map "longtouch" event.
 *	@param {integer | undefined} [options.pixelTolerance=0] pixel tolerance before drag, default 0
 *	@param {integer | undefined} [options.delay=1000] The delay for a long touch in ms, default is 1000
 */
declare class LongTouch extends ol_interaction_Interaction {
    constructor(options: any);
    delay_: any;
}
import ol_interaction_Interaction from "ol/interaction/Interaction.js";
//# sourceMappingURL=LongTouch.d.ts.map