export default Helper;
declare namespace Helper {
    function detectSupport(): boolean;
    function assign(dest: any, source: any): any;
    function mergeParams(dest: any, source: any, replace: boolean): void;
    function getUid(prefix: string, obj?: any): string;
    function setIcon(element: HTMLElement, icon?: string | HTMLElement, label?: string): string;
}
//# sourceMappingURL=Helper.d.ts.map