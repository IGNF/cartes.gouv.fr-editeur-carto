export default DrawingInteraction;
/**
 * Drawing interaction class.
 *
 * @extends {ol.interaction.Interaction}
 */
declare class DrawingInteraction {
    /**
     * Initialize drawing interaction
     * @param {*} options extend Openlayers drawing options
     * @param {Select} [options.select] - Select interaction to associate with drawing (default null)
     * @param {Boolean} [options.selectOnDrawEnd] - If true, select the feature on draw end (default false)
     */
    constructor(options: any);
    _type: any;
    info: InfoControl;
    /**
     * Retourne l'interaction de sélection
     * @returns {Select} Intéraction de sélection
     */
    getSelect(): Select;
    /**
     *
     * @param {Select} [select] Intéraction de sélection
     */
    setSelect(select?: Select): void;
    _select: Select | null | undefined;
    /**
     * Overwrite OpenLayers setMap method
     *
     * @param {Map} map - Map.
     */
    setMap(map: Map<any, any>): void;
    /** Change the source to collect features
     * @param {VectorSource} source Vector source
     */
    setSource(source: VectorSource): void;
    _source: VectorSource<Feature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>> | undefined;
    /** The source to collect features
     * @param {VectorSource} source Vector source
     * @returns {VectorSource} Vector source
     */
    getSource(): VectorSource;
    /** Set interaction active state
     * @param {Boolean} active Active state
     */
    setActive(active: boolean): void;
    /**
     * Display info message
     * @param {String} info message info
     */
    showInfo(info?: string): void;
    /** Overwrite OpenLayers Handle event on the map
     * @param {ol.MapBrowserEvent} event Event
     * @returns {Boolean} Whether to propagate the event further
     */
    handleEvent(event: ol.MapBrowserEvent): boolean;
    _modifiers: {
        shiftKey: any;
        ctrlKey: any;
    } | undefined;
}
import InfoControl from "../Controls/ContextMenu/InfoControl.js";
import Select from "ol/interaction/Select";
import VectorSource from "ol/source/Vector";
import Feature from "ol/Feature";
//# sourceMappingURL=Drawing.d.ts.map