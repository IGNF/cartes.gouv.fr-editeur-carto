export default DefaultSearchService;
/**
 * Options pour l'autocomplétion.
 */
export type AutocompleteOptions = {
    /**
     * - Options passées à Gp.Services.autoComplete
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses retournées
     */
    maximumResponses?: number | undefined;
    /**
     * - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
     */
    triggerGeocode?: boolean | undefined;
    /**
     * - Délai (ms) avant déclenchement du géocodage automatique
     */
    triggerDelay?: number | undefined;
    /**
     * - Si vrai, embellit/filtre les résultats
     */
    prettifyResults?: boolean | undefined;
};
/**
 * Options pour la recherche finale (géocodage).
 */
export type SearchOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses.
     */
    maximumResponses?: number | undefined;
    /**
     * - Active le filtrage des résultats par couche.
     */
    filterLayers?: boolean | undefined;
    /**
     * - Indexs utilisés (ex. "address,poi").
     */
    index?: string | string[] | undefined;
    /**
     * - Limite de résultats.
     */
    limit?: number | undefined;
};
/**
 * Options pour le géocodage manuel.
 */
export type GeocodeOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Texte à géocoder.
     */
    location?: string | undefined;
    /**
     * - Callback en cas de succès.
     */
    onSuccess?: Function | undefined;
    /**
     * - Callback en cas d'échec.
     */
    onFailure?: Function | undefined;
};
/**
 * Options de construction d'un service de recherche.
 */
export type AbstractSearchServiceOptions = {
    /**
     * - Clé API pour les services IGN.
     */
    apiKey?: string | undefined;
    /**
     * - Forcer HTTPS.
     */
    ssl?: boolean | undefined;
    /**
     * - Options de l'autocomplétion.
     */
    autocompleteOptions?: AutocompleteOptions | undefined;
    /**
     * - Options de la recherche finale.
     */
    searchOptions?: SearchOptions | undefined;
    /**
     * - Options de géocodage.
     */
    geocodeOptions?: GeocodeOptions | undefined;
    autocomplete?: boolean | undefined;
    index?: string | undefined;
    limit?: number | undefined;
    returnTrueGeometry?: boolean | undefined;
};
/**
 * Options pour l'autocomplétion.
 * @typedef {Object} AutocompleteOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.autoComplete
 * @property {Number} [maximumResponses] - Nombre maximal de réponses retournées
 * @property {Boolean} [triggerGeocode=false] - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
 * @property {Number} [triggerDelay=1000] - Délai (ms) avant déclenchement du géocodage automatique
 * @property {Boolean} [prettifyResults=false] - Si vrai, embellit/filtre les résultats
 */
/**
 * Options pour la recherche finale (géocodage).
 * @typedef {Object} SearchOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {Number} [maximumResponses] - Nombre maximal de réponses.
 * @property {Boolean} [filterLayers] - Active le filtrage des résultats par couche.
 * @property {String|Array<String>} [index] - Indexs utilisés (ex. "address,poi").
 * @property {Number} [limit] - Limite de résultats.
 */
/**
 * Options pour le géocodage manuel.
 * @typedef {Object} GeocodeOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {String} [location] - Texte à géocoder.
 * @property {Function} [onSuccess] - Callback en cas de succès.
 * @property {Function} [onFailure] - Callback en cas d'échec.
 */
/**
 * Options de construction d'un service de recherche.
 * @typedef {Object} AbstractSearchServiceOptions
 * @property {String} [apiKey] - Clé API pour les services IGN.
 * @property {Boolean} [ssl=true] - Forcer HTTPS.
 * @property {AutocompleteOptions} [autocompleteOptions] - Options de l'autocomplétion.
 * @property {SearchOptions} [searchOptions] - Options de la recherche finale.
 * @property {GeocodeOptions} [geocodeOptions] - Options de géocodage.
 * @property {Boolean} [autocomplete=true]
 * @property {String} [index="address,poi"]
 * @property {Number} [limit=1]
 * @property {Boolean} [returnTrueGeometry=false]
 */
/**
 * @classdesc
 * Service de recherche par défaut (implémentation simple pour tests ou données locales).
 *
 * @alias ol.service.DefaultSearchService
 * @module SearchService
 * @extends AbstractSearchService
 */
declare class DefaultSearchService extends AbstractSearchService {
    _searchTab: any;
}
import AbstractSearchService from "./AbstractSearchService";
//# sourceMappingURL=DefaultSearchService.d.ts.map