export default IGNSearchService;
/**
 * Filtres optionnels pour le géocodage.
 * Les filtres dépendent du type de recherche : adresses, toponymes ou parcelles cadastrales
 */
export type IGNSearchFilter = {
    /**
     * - Code postal (adresses, toponymes).
     */
    postalCode?: string | undefined;
    /**
     * - Code INSEE (adresses, toponymes).
     */
    inseeCode?: string | undefined;
    /**
     * - Nom de la ville (adresses, toponymes).
     */
    city?: string | undefined;
    /**
     * - Type de toponyme (toponymes uniquement).
     */
    type?: string | undefined;
    /**
     * - Code département (parcelles cadastrales uniquement).
     */
    codeDepartement?: string | undefined;
    /**
     * - Code commune (parcelles cadastrales uniquement).
     */
    codeCommune?: string | undefined;
    /**
     * - Nom de la commune (parcelles cadastrales uniquement).
     */
    nomCommune?: string | undefined;
    /**
     * - Code commune abs (parcelles cadastrales uniquement).
     */
    codeCommuneAbs?: string | undefined;
    /**
     * - Code arrondissement (parcelles cadastrales uniquement).
     */
    codeArrondissement?: string | undefined;
    /**
     * - Section cadastrale (parcelles cadastrales uniquement).
     */
    section?: string | undefined;
    /**
     * - Numéro de parcelle (parcelles cadastrales uniquement).
     */
    numero?: string | undefined;
    /**
     * - Feuille cadastrale (parcelles cadastrales uniquement).
     */
    feuille?: string | undefined;
};
/**
 * Position dans un système de coordonnées.
 */
export type Position = {
    /**
     * - Longitude.
     */
    x: number;
    /**
     * - Latitude.
     */
    y: number;
};
/**
 * Résultat d'une autocomplétion (voir {@link https://ignf.github.io/geoportal-access-lib/latest/jsdoc/Gp.Services.AutoComplete.SuggestedLocation.html})
 * Voir src/Services/AbstractSearchService.js
 */
export type AutocompleteResult = {
    /**
     * - Type de suggestion.
     */
    type: "StreetAddress" | "PositionOfInterest";
    /**
     * - Coordonnées du point, dans le système de coordonnées spécifiées.
     */
    position: Position;
    /**
     * - Nom de la commune.
     */
    commune: string;
    /**
     * - Texte complet représentant la suggestion.
     */
    fullText: string;
    /**
     * - Code postal de la suggestion.
     */
    postalCode: string;
    /**
     * - Nombre utilisé pour classigier l'importance de l'endroit suggéré de 1 (plus important) à 7 (moins important)
     */
    classification: number;
    /**
     * - Types POI détaillés.
     */
    poiType?: string[] | undefined;
    /**
     * - Nom de la rue (types "StreetAddress" seulement).
     */
    street?: string | undefined;
    /**
     * - Nature du point d'intérêt, e.g. "prefecture", "municipality"... (types "PositionOfInterest" seulement).
     */
    kind?: string | undefined;
};
/**
 * Objet envoyé pour le géocodage
 */
export type IGNSearchObject = {
    /**
     * - Objet utilisé pour faire la requête.
     * Peut être soit le résultat de l'autocomplétion ou une chaîne de caractère.
     */
    location: AutocompleteResult | string;
    /**
     * - Filtres optionnels pour la recherche
     */
    filters?: IGNSearchFilter | undefined;
};
/**
 * Erreur du service (voir {@link https://ignf.github.io/geoportal-access-lib/latest/jsdoc/Gp.Error.html})
 */
export type ErrorService = {
    /**
     * - Message d'erreur retourné par le service.
     */
    message: string;
    /**
     * - Code de statut (-1 si inconnu).
     */
    status: number;
    /**
     * - Type d'erreur (ex. "UNKNOWN_ERROR").
     */
    type: string;
    /**
     * - Nom de l'erreur (ex. "ErrorService").
     */
    name: string;
    /**
     * - Stack trace de l'erreur, si disponible.
     */
    stack?: string | undefined;
};
/**
 * Options pour l'autocomplétion.
 */
export type AutocompleteOptions = {
    /**
     * - Options passées à Gp.Services.autoComplete
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses retournées
     */
    maximumResponses?: number | undefined;
    /**
     * - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
     */
    triggerGeocode?: boolean | undefined;
    /**
     * - Délai (ms) avant déclenchement du géocodage automatique
     */
    triggerDelay?: number | undefined;
    /**
     * - Si vrai, embellit/filtre les résultats
     */
    prettifyResults?: boolean | undefined;
};
/**
 * Options pour la recherche finale (géocodage).
 */
export type SearchOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses.
     */
    maximumResponses?: number | undefined;
    /**
     * - Active le filtrage des résultats par couche.
     */
    filterLayers?: boolean | undefined;
    /**
     * - Indexs utilisés (ex. "address,poi").
     */
    index?: string | string[] | undefined;
    /**
     * - Limite de résultats.
     */
    limit?: number | undefined;
};
/**
 * Options pour le géocodage manuel.
 */
export type GeocodeOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Texte à géocoder.
     */
    location?: string | undefined;
    /**
     * - Callback en cas de succès.
     */
    onSuccess?: Function | undefined;
    /**
     * - Callback en cas d'échec.
     */
    onFailure?: Function | undefined;
};
/**
 * Options de construction d'un service de recherche.
 */
export type AbstractSearchServiceOptions = {
    /**
     * - Clé API pour les services IGN.
     */
    apiKey?: string | undefined;
    /**
     * - Forcer HTTPS.
     */
    ssl?: boolean | undefined;
    /**
     * - Options de l'autocomplétion.
     */
    autocompleteOptions?: AutocompleteOptions | undefined;
    /**
     * - Options de la recherche finale.
     */
    searchOptions?: SearchOptions | undefined;
    /**
     * - Options de géocodage.
     */
    geocodeOptions?: GeocodeOptions | undefined;
    autocomplete?: boolean | undefined;
    index?: string | undefined;
    limit?: number | undefined;
    returnTrueGeometry?: boolean | undefined;
};
/**
 * Filtres optionnels pour le géocodage.
 * Les filtres dépendent du type de recherche : adresses, toponymes ou parcelles cadastrales
 * @typedef {Object} IGNSearchFilter
 * @property {string} [postalCode] - Code postal (adresses, toponymes).
 * @property {string} [inseeCode] - Code INSEE (adresses, toponymes).
 * @property {string} [city] - Nom de la ville (adresses, toponymes).
 * @property {string} [type] - Type de toponyme (toponymes uniquement).
 * @property {string} [codeDepartement] - Code département (parcelles cadastrales uniquement).
 * @property {string} [codeCommune] - Code commune (parcelles cadastrales uniquement).
 * @property {string} [nomCommune] - Nom de la commune (parcelles cadastrales uniquement).
 * @property {string} [codeCommuneAbs] - Code commune abs (parcelles cadastrales uniquement).
 * @property {string} [codeArrondissement] - Code arrondissement (parcelles cadastrales uniquement).
 * @property {string} [section] - Section cadastrale (parcelles cadastrales uniquement).
 * @property {string} [numero] - Numéro de parcelle (parcelles cadastrales uniquement).
 * @property {string} [feuille] - Feuille cadastrale (parcelles cadastrales uniquement).
 */
/**
 * Position dans un système de coordonnées.
 * @typedef {Object} Position
 * @property {Number} x - Longitude.
 * @property {Number} y - Latitude.
 */
/**
 * Résultat d'une autocomplétion (voir {@link https://ignf.github.io/geoportal-access-lib/latest/jsdoc/Gp.Services.AutoComplete.SuggestedLocation.html})
 * Voir src/Services/AbstractSearchService.js
 *
 * @typedef {Object} AutocompleteResult
 * @property {"StreetAddress"|"PositionOfInterest"} type - Type de suggestion.
 * @property {Position} position - Coordonnées du point, dans le système de coordonnées spécifiées.
 * @property {String} commune - Nom de la commune.
 * @property {String} fullText - Texte complet représentant la suggestion.
 * @property {String} postalCode - Code postal de la suggestion.
 * @property {Number} classification - Nombre utilisé pour classigier l'importance de l'endroit suggéré de 1 (plus important) à 7 (moins important)
 * @property {Array<String>} [poiType] - Types POI détaillés.
 * @property {String} [street] - Nom de la rue (types "StreetAddress" seulement).
 * @property {String} [kind] - Nature du point d'intérêt, e.g. "prefecture", "municipality"... (types "PositionOfInterest" seulement).
 */
/**
 * Objet envoyé pour le géocodage
 * @typedef {Object} IGNSearchObject
 * @property {AutocompleteResult|String} location - Objet utilisé pour faire la requête.
 * Peut être soit le résultat de l'autocomplétion ou une chaîne de caractère.
 * @property {IGNSearchFilter} [filters] - Filtres optionnels pour la recherche
 */
/**
 * Erreur du service (voir {@link https://ignf.github.io/geoportal-access-lib/latest/jsdoc/Gp.Error.html})
 * @typedef {Object} ErrorService
 * @property {string} message - Message d'erreur retourné par le service.
 * @property {number} status - Code de statut (-1 si inconnu).
 * @property {string} type - Type d'erreur (ex. "UNKNOWN_ERROR").
 * @property {string} name - Nom de l'erreur (ex. "ErrorService").
 * @property {string} [stack] - Stack trace de l'erreur, si disponible.
 */
/**
 * Options pour l'autocomplétion.
 * @typedef {Object} AutocompleteOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.autoComplete
 * @property {Number} [maximumResponses] - Nombre maximal de réponses retournées
 * @property {Boolean} [triggerGeocode=false] - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
 * @property {Number} [triggerDelay=1000] - Délai (ms) avant déclenchement du géocodage automatique
 * @property {Boolean} [prettifyResults=false] - Si vrai, embellit/filtre les résultats
 */
/**
 * Options pour la recherche finale (géocodage).
 * @typedef {Object} SearchOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {Number} [maximumResponses] - Nombre maximal de réponses.
 * @property {Boolean} [filterLayers] - Active le filtrage des résultats par couche.
 * @property {String|Array<String>} [index] - Indexs utilisés (ex. "address,poi").
 * @property {Number} [limit] - Limite de résultats.
 */
/**
 * Options pour le géocodage manuel.
 * @typedef {Object} GeocodeOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {String} [location] - Texte à géocoder.
 * @property {Function} [onSuccess] - Callback en cas de succès.
 * @property {Function} [onFailure] - Callback en cas d'échec.
 */
/**
 * Options de construction d'un service de recherche.
 * @typedef {Object} AbstractSearchServiceOptions
 * @property {String} [apiKey] - Clé API pour les services IGN.
 * @property {Boolean} [ssl=true] - Forcer HTTPS.
 * @property {AutocompleteOptions} [autocompleteOptions] - Options de l'autocomplétion.
 * @property {SearchOptions} [searchOptions] - Options de la recherche finale.
 * @property {GeocodeOptions} [geocodeOptions] - Options de géocodage.
 * @property {Boolean} [autocomplete=true]
 * @property {String} [index="address,poi"]
 * @property {Number} [limit=1]
 * @property {Boolean} [returnTrueGeometry=false]
 */
/**
 * @classdesc
 * Service de recherche IGN (utilise les services IGN / Search wrapper).
 *
 * @alias ol.service.IGNSearchService
 * @module SearchService
 * @extends AbstractSearchService
 */
declare class IGNSearchService extends AbstractSearchService {
    options: {
        searchOptions: {
            maximumEntries: number;
            serviceOptions: {
                maximumResponses: number;
            };
            filterLayers: boolean;
        };
        geocodeOptions: {
            serviceOptions: {};
        };
        autocomplete: boolean;
        autocompleteOptions: {
            serviceOptions: {
                maximumResponses: number;
            };
            triggerGeocode: boolean;
            triggerDelay: number;
            prettifyResults: boolean;
        };
    } | undefined;
    /**
     * Label du géocodage / de la recherche
     * @type {String}
     */
    _currentGeocodingLocation: string;
    /**
     * Liste de résultats d'autocomplétion
     * @type {Array<import("./AbstractSearchService").AutocompleteResult>}
     */
    _suggestedLocations: Array<import("./AbstractSearchService").AutocompleteResult>;
    /**
     * Exécute une requête d'autocomplétion auprès du service IGN.
     * @private
     * @param {Object} settings Paramètres de la requête (texte, callbacks, etc.)
     * @param {String} settings.text Texte à compléter
     * @param {Function} settings.onSuccess Callback en cas de succès
     * @param {Function} settings.onFailure Callback en cas d'échec
     */
    private _requestAutoComplete;
    /**
     * Fonction appelée en cas de succès de l'autocomplétion.
     * @param {Object} results Résultats de la requête.
     * @param {Array<AutocompleteResult>} results.suggestedLocations Tableau de suggestions.
     */
    _onSuccessAutoComplete(results: {
        suggestedLocations: Array<AutocompleteResult>;
    }): void;
    _triggerHandler: NodeJS.Timeout | null | undefined;
    /**
     * Fonction appelée en cas d'erreur sur le service d'autocomplétion
     * @param {ErrorService} error Erreur renvoyée par le service
     */
    _onFailureAutoComplete(error: ErrorService): void;
    /**
     * this method is called by this.onAutoCompleteSearchText()
     * and it clears suggested location from duplicate entries and improve unprecise fulltext entries.
     *
     * @param {Array} autocompleteResults - Array of autocompleteResults to display
     * @private
     */
    private _prettifyAutocompleteResults;
    /**
     * this method is called by Gp.Services.autoComplete callback in case of success
     * (cf. this.onAutoCompleteSearchText), for suggested locations with null coordinates
     * (case of postalCode research for instance).
     * Send a geocode request with suggested location 'fullText' attribute, to get its coordinates and display it in autocomplete results list container.
     *
     * @param {Gp.Services.AutoCompleteResponse.SuggestedLocation} suggestedLocation - autocompletion result (with null coordinates) to be geocoded
     * @param {Number} i - suggestedLocation position in Gp.Services.AutoCompleteResponse.suggestedLocations autocomplete results list
     * @private
     */
    private _getGeocodeCoordinatesFromFullText;
    _clearResults(): void;
    /**
     * Lance une recherche sur les services de géocodage de l'IGN
     * @see {@link https://data.geopf.fr/geocodage/search}
     * @see {@link https://data.geopf.fr/geocodage/openapi}
     * @param {IGNSearchObject} object Recherche
     * @abstract
     */
    search(object: IGNSearchObject): void;
    /**
     * this method is called by this.onAutoCompleteSearch()
     * and executes a request to the service.
     *
     * @param {Object} settings - service settings
     * @param {String} settings.location - text
     * @param {Function} settings.onSuccess - callback
     * @param {Function} settings.onFailure - callback
     * @private
     */
    private _requestGeocoding;
    /** Get features based on current search result
     * @param {Number} index Index of the result
     * @returns {Object} Object containing feature and extent (if any)
     */
    getResultFeatures(index: number): any;
    /**
     * Fonction appelée en cas de succès du géocodage
     *
     * @param {Object} results Résultats de la recherche
     * @private
     */
    private _onSuccessSearch;
    /**
     * Fonction appelée en cas d'erreur renvoyée par le service de géocodage.
     * @param {AutocompleteResult} location Localisation de l'autocomplétion.
     * @param {ErrorService} error Erreur renvoyée par le service.
     */
    _onFailureSearch(location: AutocompleteResult, error: ErrorService): void;
}
import AbstractSearchService from "./AbstractSearchService";
//# sourceMappingURL=IGNSearchService.d.ts.map