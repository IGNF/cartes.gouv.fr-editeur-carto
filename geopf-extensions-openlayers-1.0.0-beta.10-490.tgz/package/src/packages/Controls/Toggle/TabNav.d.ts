export default TabNav;
/**
 * Objet représentant un item de navigation tertiaire.
 * Voir dans le fichier TabNavItem.js pour plus d'infos.
 */
export type TabNavItemOptions = {
    /**
     * - Label du bouton
     */
    label: string;
    /**
     * - Contenu lié au bouton
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Titre du bouton
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du bouton
     */
    icon?: string | undefined;
    /**
     * - Callback appelé à l'ouverture de l'onglet
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture de l'onglet
     */
    onClose?: Function | undefined;
};
/**
 * Options du constructeur TabNav
 */
export type TabNavOptions = {
    /**
     * - Liste des items de navigation
     */
    items?: TabNavItemOptions | undefined;
    /**
     * - Label ARIA de la navigation
     */
    label?: string | undefined;
    /**
     * - Conteneur du contenu lié aux onglets. Si non fourni, en créé un et l'ajoute juste après les liens.
     */
    contentContainer?: HTMLElement | undefined;
};
/**
 * Objet représentant un item de navigation tertiaire.
 * Voir dans le fichier TabNavItem.js pour plus d'infos.
 *
 * @typedef {Object} TabNavItemOptions
 * @property {String} label - Label du bouton
 * @property {String|HTMLElement} [content] - Contenu lié au bouton
 * @property {String} [title] - Titre du bouton
 * @property {String} [icon] - Classe CSS de l'icône du bouton
 * @property {Function} [onOpen] - Callback appelé à l'ouverture de l'onglet
 * @property {Function} [onClose] - Callback appelé à la fermeture de l'onglet
 */
/**
 * Options du constructeur TabNav
 * @typedef {Object} TabNavOptions
 * @property {TabNavItemOptions} [items] - Liste des items de navigation
 * @property {String} [label] - Label ARIA de la navigation
 * @property {HTMLElement} [contentContainer] - Conteneur du contenu lié aux onglets. Si non fourni, en créé un et l'ajoute juste après les liens.
 */
/**
 * @classdesc
 * Classe gérant une navigation tertiaire avec onglets.
 *
 * @alias TabNav
 * @module TabNav
 * @extends {Control}
 */
declare class TabNav extends Control {
    /**
     * Constructeur du TabNav.
     * @constructor
     * @param {TabNavOptions} options Options du constructeur
     */
    constructor(options?: TabNavOptions);
    navigationList: Element | null;
    /**
     * @param {TabNavOptions} options Options de construction
     */
    _initialize(options: TabNavOptions): void;
    tabNavClass: string | undefined;
    _uid: any;
    /**
     * @type {Collection<TabNavItem>}
     */
    items: Collection<TabNavItem> | undefined;
    selectors: {
        NAVIGATION: string;
        NAVIGATION_LIST: string;
        NAVIGATION_ITEM: string;
        NAVIGATION_LINK: string;
        CURRENT_LINK: string;
        OPEN_TAB: string;
        CLOSE_TAB: string;
    } | undefined;
    contentContainer: HTMLElement | undefined;
    setMap(map: any): void;
    /**
     * Crée le conteneur principal de la navigation.
     * @protected
     * @param {TabNavOptions} options Options de construction
     * @returns {HTMLElement} Élément div de navigation
     */
    protected _initContainer(options: TabNavOptions): HTMLElement;
    /**
     * @param {TabNavOptions} options Options du constructeur
     */
    _initEvents(options: TabNavOptions): void;
    /**
     * Ajoute plusieurs items à la navigation.
     * @param {TabNavItemOptions} items Liste des items à ajouter
     */
    addItems(items: TabNavItemOptions): void;
    /**
     * Ajoute un item à la navigation.
     * @param {TabNavItem|TabNavItemOptions} options Item à ajouter
     */
    addItem(options: TabNavItem | TabNavItemOptions): void;
    /**
     * Booléen retournant le nombre d'item dans la navigation
     * @returns {Boolean} Vrai si contient des éléments
     */
    hasNavItem(): boolean;
    /**
     * Retourne le lien actuellement sélectionné.
     * @returns {TabNavItem|null} Bouton actuellement sélectionné
     */
    getCurrentLink(): TabNavItem | null;
    /**
     * Définit le lien courant et gère l'affichage du contenu.
     * @param {TabNavItem} link Bouton à activer
     */
    setCurrentLink(link: TabNavItem): void;
    currentItem: TabNavItem | undefined;
    /**
     * Vérifie si la navigation contient des items.
     * @returns {Boolean} True si au moins un item existe
     */
    hasItems(): boolean;
    /**
     * Retourne l'élément principal de la navigation.
     * @returns {HTMLElement} Élément div de navigation
     */
    getElement(): HTMLElement;
    /**
     * Affiche la navigation.
     */
    show(): void;
    /**
     * Masque la navigation.
     */
    hide(): void;
    /**
     * Affiche un item.
     * @param {TabNavItem} item Item à afficher
     */
    showItem(item: TabNavItem): void;
    /**
     * Masque un item.
     * @param {TabNavItem} item Item à masquer
     */
    hideItem(item: TabNavItem): void;
    /**
     * Sélectionne le premier onglet.
     */
    selectFirst(): void;
    /**
     * Supprime tous les items de la navigation.
     */
    clear(): void;
}
import Control from "../Control";
import TabNavItem from "./TabNavItem";
import Collection from "ol/Collection";
//# sourceMappingURL=TabNav.d.ts.map