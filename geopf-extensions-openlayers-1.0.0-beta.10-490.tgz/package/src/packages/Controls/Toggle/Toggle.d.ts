export default Toggle;
/**
 * Options de base du toggle
 */
export type ToggleOptions = {
    /**
     * - Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
};
/**
 * @typedef {Object} ToggleOptions Options de base du toggle
 * @property {String} [label] - Libellé associé à l'input.
 * @property {String} [title] - Attribut title / aria-label.
 * @property {String} [position] - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
 * @property {String|HTMLElement} [icon] - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
 */
/**
 * @classdesc
 * Contrôle de base créant un toggle simple, sans interaction ou contenu.
 *
 * @alias ol.control.Toggle
 * @module Toggle
 */
declare class Toggle extends Control {
    /**
     * Constructeur du contrôle Toggle.
     * @constructor
     * @param {ToggleOptions} options Options du constructeur
     * @fires change:active
     */
    constructor(options: ToggleOptions);
    setMap(map: any): void;
    /**
     * Retourne l'élément HTML contenant le contrôle.
     * Méthode créé pour ne pas créer de conflits avec les
     * autre contrôles.
     *
     * @returns {HTMLElement} Élément HTML
     */
    getContainer(): HTMLElement;
    /**
     * Active ou désactive le contrôle (désactive l'input / bouton).
     * @param {Boolean} active Indique si le contrôle doit être activé ou non
     * @param {Boolean} [silent] Si vrai, n'envoie pas d'événement `change:active`
     * @fires Toggle#change:active
     * @public
     */
    public setActive(active: boolean, silent?: boolean): void;
    /**
     * Active ou désactive le contrôle (désactive l'input / bouton).
     * @returns {Boolean} Vrai si le bouton est pressé
     * @public
     */
    public getActive(): boolean;
    /**
     * Change l'état du toggle.
     * Le paramètre force permet de n'appliquer que l'activation / la désactivation du toggle.
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/DOMTokenList/toggle} Inspiré de la méthode Element.classList.toggle.
     * @param {Boolean} force Force l'activation / désactivation du toggle si donné.
     * @returns {Boolean} Vrai si le toggle est activé, faux sinon.
     */
    toggleActive(force: boolean): boolean;
    /**
     * Initialise le contrôle Toggle (appelé par le constructeur).
     * @protected
     * @param {ToggleOptions} options Options du constructeur
     */
    protected _initialize(options: ToggleOptions): void;
    ariaAttribute: string | undefined;
    /**
     * Nom de la classe (heritage)
     * @private
     */
    private CLASSNAME;
    options: ToggleOptions | undefined;
    _uid: any;
    /**
     * Ajoute les écouteurs d'événements sur les éléments du contrôle.
     * @protected
     * @param {ToggleOptions} options Options du constructeur
     */
    protected _initEvents(options: ToggleOptions): void;
    /**
     * Initialise le conteneur DOM principal du contrôle.
     * @protected
     * @param {ToggleOptions} options Options du constructeur
     */
    protected _initContainer(options: ToggleOptions): void;
    button: HTMLButtonElement | undefined;
    /**
     * Gère le clic sur le bouton
     * @param {PointerEvent} e Événement au clic sur le bouton
     */
    _onButtonClick(e: PointerEvent): void;
}
import Control from "../Control";
//# sourceMappingURL=Toggle.d.ts.map