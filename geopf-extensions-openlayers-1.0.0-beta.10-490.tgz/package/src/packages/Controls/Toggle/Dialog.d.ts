export default Dialog;
/**
 * Options du constructeur Dialog
 */
export type DialogOptions = {
    /**
     * - Identifiant unique du dialog
     */
    id?: string | undefined;
    /**
     * - Titre du dialog
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du dialog
     */
    icon?: string | undefined;
    /**
     * - Contenu du dialog (HTML string ou élément DOM)
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Position du dialog ("left" ou "right")
     */
    position?: string | undefined;
    /**
     * - Taille du dialog ("sm" ou "md")
     */
    size?: string | undefined;
    /**
     * - Nom de classe CSS additionnel
     */
    className?: string | undefined;
    /**
     * - Liste des items de navigation tertiaire
     */
    items?: any[] | undefined;
    /**
     * - Attribut aria label de la navigation tertiaire
     */
    labelTabNav?: string | undefined;
    /**
     * - Callback appelé à l'ouverture du dialog
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture du dialog
     */
    onClose?: Function | undefined;
};
/**
 * Option pour le pied de page du dialogue.
 */
export type FooterOption = {
    /**
     * Configurations des boutons de pied de page du dialogue.
     */
    buttons?: FooterButtonOption[] | undefined;
    /**
     * Contenu du footer, placé avant les boutons
     */
    content?: string | HTMLElement | undefined;
};
/**
 * Bouton à mettre dans le pied de page d'un dialog.
 */
export type FooterButtonOption = {
    /**
     * - Label du bouton.
     */
    label: string;
    /**
     * - Attribut titre du bouton.
     */
    title?: string | undefined;
    /**
     * - Icône du bouton.
     */
    icon?: string | undefined;
    /**
     * - Tag du bouton ("a" ou "button").
     */
    markup?: string | undefined;
    /**
     * - Type de bouton (seulement pour l'élément <button>).
     */
    type?: string | undefined;
    /**
     * - Classe à ajouter au bouton.
     */
    className?: string | undefined;
    /**
     * - Si vrai, ferme le dialog.
     */
    close?: boolean | undefined;
    /**
     * - Fonction au clic sur le bouton.
     */
    callback?: Function | undefined;
    /**
     * - Attributs additionnels à ajouter au bouton.
     */
    attributes?: any;
};
/**
 * Objet représentant un item de navigation tertiaire.
 * Voir dans le fichier TabNavItem.js pour plus d'infos.
 */
export type TabNavItemOptions = {
    /**
     * - Label du bouton
     */
    label: string;
    /**
     * - Contenu lié au bouton
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Titre du bouton
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du bouton
     */
    icon?: string | undefined;
    /**
     * - Callback appelé à l'ouverture de l'onglet
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture de l'onglet
     */
    onClose?: Function | undefined;
};
/**
 * @classdesc
 * Classe gérant un dialog HTML avec titre, icône et contenu.
 *
 * @alias Dialog
 * @module Dialog
 */
declare class Dialog extends ControlExtended {
    /**
     * Renvoie le dialog correspondant à l'id donné
     * @param {String} id Id du dialog
     * @returns {AbstractDialog} Instance du dialog avec l'id correspondant
     * @throws {Error} Si aucun dialogue avec cet id n'existe
     * @static
     */
    static getDialog(id: string): AbstractDialog;
    /**
     * Constructeur du Dialog.
     * @constructor
     * @param {DialogOptions} options Options du constructeur
     */
    constructor(options?: DialogOptions);
    dialogTitle: Element;
    dialogIcon: Element;
    dialogContent: Element;
    footerContent: Element;
    setMap(map: any): void;
    /**
     * @protected
     * @param {DialogOptions} options Options du constructeur
     */
    protected _initialize(options: DialogOptions): void;
    dialogClass: string | undefined;
    _uid: number | undefined;
    selectors: {
        TITLE: string;
        BTN_CLOSE: string;
        ICON: string;
        CONTENT: string;
        FOOTER: string;
        FOOTER_CONTENT: string;
        BUTTON_GROUP: string;
        BUTTONS: string;
        OPEN_EVENT: string;
        CHANGE_CONTENT: string;
        CLOSE_EVENT: string;
    } | undefined;
    tabNav: TabNav | null | undefined;
    onOpenCallback: Function | undefined;
    onCloseCallback: Function | undefined;
    /**
     * @protected
     * @param {DialogOptions} options Options de construction
     */
    protected _initContainer(options: DialogOptions): void;
    closeBtn: HTMLButtonElement | undefined;
    /**
     * Ajoute les écouteurs d'événements sur les éléments du contrôle.
     * @protected
     * @param {DialogOptions} options Options du constructeur
     */
    protected _initEvents(options: DialogOptions): void;
    /**
     * Ajoute ou remplace la fonction lancée à l'ouverture
     * du dialog.
     *
     * @param {Function} onOpen Fonction à l'ouverture du dialog.
     */
    setOnOpen(onOpen: Function): void;
    onOpenFn: any;
    /**
     * Ajoute ou remplace la fonction lancée à la fermeture
     * du dialog.
     *
     * @param {Function} onClose Fonction à la fermeture du dialog.
     */
    setOnClose(onClose: Function): void;
    onCloseFn: any;
    /**
     * @param {Function} callback Fonction à l'ouverture du dialog.
     * @param {Boolean} [once=false] Si vrai, écoute une seule fois.
     */
    onOpen(callback: Function, once?: boolean): void;
    /**
     * @param {Function} callback Fonction à la fermeture du dialog.
     * @param {Boolean} [once=false] Si vrai, écoute une seule fois.
     */
    onClose(callback: Function, once?: boolean): void;
    /**
     * Définit la position du panneau (droite ou gauche).
     * @param {String} position Position du panneau ("left" ou "right")
     */
    setPos(position: string): void;
    /**
     * Définit la taille du panneau (sm ou md).
     * @param {String} size Taille du panneau (sm ou md)
     */
    setSize(size: string): void;
    /**
     * Fonction utilitaire pour paramétrer facilement le dialog.
     *
     * @param {Object} options Élements du dialog
     * @param {String} options.title Titre
     * @param {String} options.icon Icône
     * @param {String|Element} options.content Contenu du dialog.
     * @param {FooterOption} options.footer Contenu du dialog.
     */
    setContent(options?: {
        title: string;
        icon: string;
        content: string | Element;
        footer: FooterOption;
    }): void;
    /**
     * Fonction utilitaire pour paramétrer facilement l'icône.
     * @param {String} icon Icône
     * @param {String} [title] Titre
     */
    setIcon(icon: string, title?: string): void;
    iconClass: string | undefined;
    /**
     * Retourne l'élément principal du contrôle.
     * @returns {HTMLDialogElement} Élément HTML du contrôle (balise dialog)
     */
    getElement(): HTMLDialogElement;
    /**
     * Retourne le titre du dialog (contenu).
     * @returns {String} Contenu du titre
     */
    getDialogTitle(): string;
    /**
     * Ajoute un titre au dialog.
     * @param {String} title Titre à remplacer
     */
    setDialogTitle(title: string): void;
    /**
     * Retourne le contenu du dialog.
     *
     * @returns {Element} Contenu du dialog
     */
    getDialogContent(): Element;
    /**
     * Ajoute un contenu au dialog.
     *
     * @param {Element|String|null} content Contenu du dialog
     * @param {Boolean} [clear=true] Si vrai, efface le contenu du dialog
     */
    setDialogContent(content: Element | string | null, clear?: boolean): void;
    /**
     * Retourne le contenu du dialog.
     *
     * @returns {Element} Contenu du dialog
     */
    getFooterContent(): Element;
    /**
     * Ajoute du contenu au footer.
     *
     * @param {FooterOption} options Contenu du dialog
     * @param {Boolean} [clear=true] Si vrai, efface le contenu du dialog
     */
    setFooterContent(options: FooterOption, clear?: boolean): void;
    /**
     * Ajoute des boutons au footer.
     * @param {Array<FooterButtonOption>} buttons Boutons à ajouter
     */
    addFooterButtons(buttons: Array<FooterButtonOption>): void;
    /**
     * Ajoute un bouton au footer
     * @param {FooterButtonOption|HTMLElement} button Bouton à ajouter
     */
    addFooterButton(button: FooterButtonOption | HTMLElement): void;
    /**
     * Sélectionne le premier élément du dialog correspondant
     * au sélecteur CSS.
     *
     * @param {String} selector Sélecteur CSS.
     * @returns {Element} Premier élément correspondant au sélecteur.
     */
    querySelector(selector: string): Element;
    /**
     * Sélectionne tous les éléments du dialog correspondant
     * au selecteur CSS.
     *
     * @param {String} selector Sélecteur CSS
     * @returns {NodeList} Liste des élements correspondant au sélecteur
     */
    querySelectorAll(selector: string): NodeList;
    /**
     * Ouvre le dialog.
     */
    show(): void;
    /**
     * Ferme le dialog.
     */
    close(): void;
    /**
     * Vérifie si le dialog est ouvert.
     * @returns {Boolean} True si le dialog est ouvert
     */
    isOpen(): boolean;
    /**
     * Ajoute une navigation tertiaire au dialog.
     * @param {Array<TabNavItem>} items Liste des items de navigation
     * @param {String} [label] Attribut aria label de la navigation tertiaire
     */
    setTabNav(items: Array<TabNavItem>, label?: string): void;
    /**
     * Retourne l'instance de la navigation tertiaire.
     * @returns {TabNav|null} Instance de TabNav ou null
     */
    getTabNav(): TabNav | null;
    /**
     * Ajoute un item à la navigation tertiaire.
     * @param {TabNavItemOptions} item Item à ajouter
     */
    addTabNavItem(item: TabNavItemOptions): void;
    /**
     * Supprime tous les items de la navigation tertiaire.
     */
    clearTabNav(): void;
    #private;
}
import ControlExtended from "../Control";
import TabNav from "./TabNav";
//# sourceMappingURL=Dialog.d.ts.map