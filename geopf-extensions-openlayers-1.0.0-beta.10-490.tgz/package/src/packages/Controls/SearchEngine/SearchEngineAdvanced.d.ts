export default SearchEngineAdvanced;
/**
 * Callback appelé lors du clic sur un bouton personnalisé du popup.
 */
export type PopupButtonClickCallback = (feature: Feature) => boolean;
/**
 * Options pour ajouter un bouton de popup
 */
export type PopupButton = {
    /**
     * - Attribut title du bouton.
     */
    label: string;
    /**
     * - Classe(s) CSS à appliquer au bouton.
     */
    className?: string | undefined;
    /**
     * - Classe d'icône à ajouter (ex: "fr-icon-delete-line").
     */
    icon?: string | undefined;
    /**
     * - Attributs HTML supplémentaires (clé/valeur).
     */
    attributes?: any;
    /**
     * - Fonction appelée au clic sur le bouton.
     */
    onClick: PopupButtonClickCallback;
};
/**
 * Options pour l'autocomplétion.
 */
export type AutocompleteOptions = {
    /**
     * - Options passées à Gp.Services.autoComplete
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses retournées
     */
    maximumResponses?: number | undefined;
    /**
     * - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
     */
    triggerGeocode?: boolean | undefined;
    /**
     * - Délai (ms) avant déclenchement du géocodage automatique
     */
    triggerDelay?: number | undefined;
    /**
     * - Si vrai, embellit/filtre les résultats
     */
    prettifyResults?: boolean | undefined;
};
/**
 * Options pour la recherche finale (géocodage).
 */
export type SearchOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses.
     */
    maximumResponses?: number | undefined;
    /**
     * - Active le filtrage des résultats par couche.
     */
    filterLayers?: boolean | undefined;
    /**
     * - Indexs utilisés (ex. "address,poi").
     */
    index?: string | string[] | undefined;
    /**
     * - Limite de résultats.
     */
    limit?: number | undefined;
};
/**
 * Options pour le géocodage manuel.
 */
export type GeocodeOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Texte à géocoder.
     */
    location?: string | undefined;
    /**
     * - Callback en cas de succès.
     */
    onSuccess?: Function | undefined;
    /**
     * - Callback en cas d'échec.
     */
    onFailure?: Function | undefined;
};
/**
 * Options de construction d'un service de recherche.
 */
export type AbstractSearchServiceOptions = {
    /**
     * - Clé API pour les services IGN.
     */
    apiKey?: string | undefined;
    /**
     * - Forcer HTTPS.
     */
    ssl?: boolean | undefined;
    /**
     * - Options de l'autocomplétion.
     */
    autocompleteOptions?: AutocompleteOptions | undefined;
    /**
     * - Options de la recherche finale.
     */
    searchOptions?: SearchOptions | undefined;
    /**
     * - Options de géocodage.
     */
    geocodeOptions?: GeocodeOptions | undefined;
    autocomplete?: boolean | undefined;
    index?: string | undefined;
    limit?: number | undefined;
    returnTrueGeometry?: boolean | undefined;
};
/**
 * Options pour le contrôle SearchEngineBase.
 */
export type SearchEngineBaseOptions = {
    /**
     * - Élément DOM ou sélecteur cible.
     */
    target?: string | HTMLElement | undefined;
    /**
     * - Texte du titre du bouton.
     */
    title?: string | undefined;
    /**
     * - Label affiché.
     */
    label?: string | undefined;
    /**
     * - Texte d'aide.
     */
    hint?: string | undefined;
    /**
     * - Comportement en tant que barre de recherche.
     */
    search?: boolean | undefined;
    /**
     * - Si vrai, le contrôle est repliable.
     */
    collapsible?: string | undefined;
    /**
     * - Libellé ARIA.
     */
    ariaLabel?: string | undefined;
    /**
     * - Placeholder de l'input.
     */
    placeholder?: string | undefined;
    /**
     * - Nombre minimal de caractères pour autocomplétion.
     */
    minChars?: number | undefined;
    /**
     * - Nombre maximal d'entrées affichées.
     */
    maximumEntries?: number | undefined;
    /**
     * - Gestion historique local (false|true|string).
     */
    historic?: string | boolean | undefined;
    /**
     * - Service de recherche.
     */
    searchService?: AbstractSearchService | undefined;
};
/**
 * Options pour le contrôle SearchEngineGeocodeIGN.
 * Étend SearchEngineBaseOptions et ajoute les options spécifiques du service IGN.
 */
export type SearchEngineGeocodeIGNOptions = SearchEngineBaseOptions & {
    serviceOptions?: AbstractSearchServiceOptions;
};
/**
 * Options pour le contrôle SearchEngineAdvanced.
 */
export type SearchEngineAdvancedOptions = {
    /**
     * - Liste des recherches avancées à intégrer.
     */
    advancedSearch?: AbstractAdvancedSearch[] | undefined;
    /**
     * - Boutons personnalisés à ajouter dans le popup.
     */
    popupButtons?: PopupButton[] | undefined;
    /**
     * - Options pour le moteur de recherche de base.
     */
    baseSearchOptions?: SearchEngineGeocodeIGNOptions | undefined;
    /**
     * - Élément DOM ou sélecteur cible.
     */
    target?: string | HTMLElement | undefined;
    /**
     * - Titre du contrôle.
     */
    title?: string | undefined;
    /**
     * - Label affiché.
     */
    label?: string | undefined;
    /**
     * - Texte d'aide.
     */
    hint?: string | undefined;
    /**
     * - Comportement en tant que barre de recherche.
     */
    search?: boolean | undefined;
    /**
     * - Libellé ARIA.
     */
    ariaLabel?: string | undefined;
    /**
     * - Placeholder de l'input.
     */
    placeholder?: string | undefined;
    /**
     * - Nombre minimal de caractères pour autocomplétion.
     */
    minChars?: number | undefined;
    /**
     * - Nombre maximal d'entrées affichées.
     */
    maximumEntries?: number | undefined;
    /**
     * - Gestion historique local (false|true|string).
     */
    historic?: string | boolean | undefined;
    /**
     * - Service de recherche.
     */
    searchService?: AbstractSearchService | undefined;
};
/**
 * @classdesc
 * Contrôle de recherche avancée permettant de rechercher via d'autres manières.
 * Gère aussi l'ajout des élements sur la carte etc.
 *
 * @extends {Control}
 * @module SearchEngineAdvanced
 */
declare class SearchEngineAdvanced extends Control {
    /**
     * Constructeur du contrôle de recherche avancée.
     * @param {SearchEngineAdvancedOptions} options - Options du constructeur.
     */
    constructor(options: SearchEngineAdvancedOptions);
    geolocation: Geolocation;
    layer: Vector<VectorSource<OlFeature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>>, OlFeature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>>;
    selectInteraction: Select;
    popup: Overlay;
    /**
     * Initialise les options du contrôle.
     * @param {SearchEngineAdvancedOptions} options - Options du constructeur.
     * @private
     */
    private initialize;
    /**
     * Nom de la classe (heritage)
     * @private
    */
    private CLASSNAME;
    /**
     * @type {Array<AbstractAdvancedSearch>}
     */
    _searchForms: Array<AbstractAdvancedSearch>;
    /**
     * Si vrai, écoute les clics sur le document pour gérer
     * la modale de recherche avancée
     * @type {Boolean}
     */
    listenToClick: boolean | undefined;
    /**
     * @override
     * @param {Map|null} map Carte cible
     */
    override setMap(map: Map | null): void;
    /**
     * Retourne la couche utilisée pour afficher les résultats.
     * @returns {Layer} Couche des résultats
     */
    getLayer(): Layer;
    /**
     * Initialise les événements du contrôle (géolocalisation, navigation clavier, recherche).
     * @param {SearchEngineAdvancedOptions} options Options du constructeur.
     * @private
     */
    private _initEvents;
    /**
     * Crée un événement de recherche à partir d'un objet (Feature ou Point).
     * @param {Object|Point|OlFeature} obj Objet à afficher (Feature ou Point)
     * @param {String} [info] Texte affiché dans la popup
     * @returns {Object} Événement normalisé de type "search"
     */
    createEvent(obj: any | Point | OlFeature, info?: string): any;
    /**
     * Initialise le conteneur principal du contrôle et les sous-composants.
     * @param {SearchEngineAdvancedOptions} options Options du constructeur
     * @private
     */
    private _initContainer;
    baseSearchEngine: SearchEngineGeocodeIGN | undefined;
    locationBtn: HTMLButtonElement | undefined;
    advancedBtn: HTMLButtonElement | undefined;
    advancedContainer: HTMLDivElement | undefined;
    eraseBtn: HTMLButtonElement | undefined;
    /**
     * Fonction active si la recherche avancée est active
     * @param {PointerEvent} e Événement de clic sur le document
     */
    _onDocumentClick(e: PointerEvent): void;
    /**
     * Ajoute les résultats (features) sur la carte et ajuste la vue.
     * @param {Object} e Événement de recherche contenant result/extent
     */
    addResultToMap(e: any): void;
    /**
     * Ajoute les infos au popup
     * @param {Feature} [feature] Feature à ajouter. Si non fourni
     * @param {Number[]} [position] Position du popup
     */
    _setPopupInfo(feature?: Feature, position?: number[]): void;
    /**
     * Callback lors de la sélection d'une feature (affiche le popup).
     * @param {SelectEvent} e Événement de sélection
     * @private
     */
    private _onSelectElement;
    /**
     * Crée et retourne l'overlay popup pour afficher les infos de feature.
     * @private
     * @param {PopupButton[]} popupButtons - Bouton à ajouter dans le popup (en plus de la suppression / fermeture).
     * @returns {Overlay} Overlay du popups
     */
    private _createPopup;
    _popupDiv: HTMLDivElement | undefined;
    _popupContent: HTMLDivElement | undefined;
    _popupBtns: HTMLDivElement | undefined;
    /**
     * Définit le contenu HTML du popup.
     * @param {String} content Contenu HTML à afficher
     */
    setPopupContent(content: string): void;
    /**
     * Crée le bouton de fermeture du popup.
     * @returns {HTMLButtonElement} Bouton de fermeture
     * @private
     */
    private _addCloseButton;
    /**
     * Ferme le popup et désélectionne la feature.
     * @returns {Boolean} false
     * @private
     */
    private _closePopup;
    /**
     * Crée le bouton de suppression du marqueur.
     * @returns {HTMLButtonElement} Bouton de suppression
     * @private
     */
    private _addRemoveButton;
    /**
     * Supprime la feature sélectionnée de la couche et ferme le popup.
     * @private
     */
    private _removeFeature;
    /**
     * Crée un bouton personnalisé pour le popup.
     * @param {PopupButton} popupButton - Configuration du bouton.
     * @returns {HTMLButtonElement} Bouton HTML
     */
    _createCustomPopupButton(popupButton: PopupButton): HTMLButtonElement;
    /**
     * Crée le bouton de géolocalisation.
     * @returns {HTMLButtonElement} Bouton de géolocalisation
     * @private
     */
    private _getGeolocButton;
    /**
     * Callback lors d'un résultat de recherche avancée.
     * @param {Object} e Événement de recherche avancée
     * @private
     */
    private onAdvancedSearchResult;
    /**
     * Ferme toutes les accordéons et affiche les sections
     */
    closeAllSections(): void;
}
import Feature from "ol/Feature";
import AbstractSearchService from "../../Services/AbstractSearchService";
import AbstractAdvancedSearch from "./AbstractAdvancedSearch";
import Control from "../Control";
import Geolocation from "ol/Geolocation";
import OlFeature from "ol/Feature";
import VectorSource from "ol/source/Vector";
import Vector from "ol/layer/Vector";
import Select from "ol/interaction/Select";
import Overlay from "ol/Overlay.js";
import Map from "ol/Map";
import { Layer } from "ol/layer";
import Point from "ol/geom/Point";
import SearchEngineGeocodeIGN from "./SearchEngineGeocodeIGN";
//# sourceMappingURL=SearchEngineAdvanced.d.ts.map