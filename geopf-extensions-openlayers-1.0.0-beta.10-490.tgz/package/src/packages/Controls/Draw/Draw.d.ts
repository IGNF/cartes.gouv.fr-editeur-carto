export default Draw;
export type DrawOptions = {
    /**
     * Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
    /**
     * Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * Taille du panneau ("sm" ou "lg").
     */
    size?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Position du panneau ("left" ou "right").
     */
    dialogPosition?: string | undefined;
    /**
     * Interaction de sélection lié au contrôle. Si aucune interaction n'est donnée, ajoute une interaction de type {@link SelectingInteraction SelectingInteraction}.
     */
    select?: Select | undefined;
    /**
     * Source à ajouter au contrôle initialement. Peut-être fait après via la méthode `setSource`. Si aucune source n'est donnée, en ajoute une de base.
     */
    source?: VectorSource<Feature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>> | undefined;
    /**
     * Si faux, n'ajoute pas d'interaction pour modifier les objets. Sinon, ajoute une interaction de type {@link ModifyingInteraction ModifyingInteraction}, héritant de {@link https://openlayers.org/en/latest/apidoc/module-ol_interaction_Modify-Modify.html Modify}, qui s'active à la sélection d'un objet. Une interaction de type `Modify` peut aussi être passée en paramètre (auquel cas ).
     */
    modify?: boolean | Modify | undefined;
    /**
     * Si vrai, ajoute une interaction {@link https://openlayers.org/en/latest/apidoc/module-ol_interaction_Snap-Snap.html Snap}, qui s'active au moment du dessin. La source utilisée est celle définie via la méthode `setSource` du contrôle. Une interaction de type `Snap` peut aussi être passée en paramètre.
     */
    snap?: boolean | Snap | undefined;
    /**
     * Si vrai, ajoute une couche par défaut à la carte. Cela n'a pas d'effet si une source est donnée via le paramètrr `source`.
     */
    addToMap?: boolean | undefined;
    /**
     * Si vrai, ajoute un panneau de style qui sera contrôlé par la sélection liée à ce contrôle. Si faux, n'ajoute aucun style.
     * Le contenu de ce panneau est géré par les formulaires donné dans le paramètre `forms`.
     * Un dialogue peut aussi être mis directement sur ce paramètre.
     */
    style?: boolean | Dialog | undefined;
    /**
     * Fonction par défaut à appliquer lors d'un changement de style. 3 valeurs sont possibles :
     * - Aucune valeur / `true` : Modifie le style des features sélectionnés. Aucun événement style ne sera envoyé sur le contrôle Draw (il est possible de les écouter via `getStyleDialog().on("style")`).
     * - `false` : Aucune action par défaut n'est effectuée. Les modifications du style sont écoutable via les événements de type `"style"` (`draw.on("style", callback)`);
     * - fonction de type {@link OnStyleCallBack OnStyleCallBack} : La fonction sera appliquée, aucun événement ne sera envoyé sur le contrôle Draw (il est possible de les écouter via `getStyleDialog().on("style")`).
     *
     * Le paramètre n'est pas pris en compte si `style=false`.
     */
    onStyle?: boolean | OnStyleCallBack | undefined;
    /**
     * Si `style=true`, ajoute les formulaires dans le dialogue. Si `style=true` mais que le paramètre est vide ou nul, des formulaires par défauts seront ajoutés. Non pris en compte si `style=false`.
     */
    forms?: StyleDialogTabNav[] | undefined;
    /**
     * Interactions à ajouter dans le contrôle. Mettre à `false` pour ne pas ajouter d'interactions par défaut. aucune Si aucun objet n'est donné, ajoutera trois interactions de dessin, de types respectifs : `Point`, `LineString`, `Polygon`. Voir interaction de dessin openlayer : {@link https://openlayers.org/en/latest/apidoc/module-ol_interaction_Draw-Draw.html | Draw}
     */
    drawingInteractions?: boolean | InteractionOptions[] | undefined;
};
export type OnStyleCallBack = (property: string, value: any, features: Array<Feature>) => any;
/**
 * Options pour une navigation tertiaire du dialogue de style.
 */
export type StyleDialogTabNav = {
    /**
     * Libellé de la navigation.
     */
    label: string;
    /**
     * Formulaire de style correspondant.
     */
    form: FlatStyleForm;
    /**
     * Titre associé (attribut title).
     */
    title?: string | undefined;
};
export type InteractionOptions = {
    /**
     * - L'interaction de dessin OpenLayers à ajouter (Voir {@link https://openlayers.org/en/latest/apidoc/module-ol_interaction_Interaction-Interaction.html | Interaction})
     */
    interaction: DrawInteraction;
    /**
     * - Libellé de l'interaction
     */
    label: string;
    /**
     * - Icône de l'interaction
     */
    icon?: string | undefined;
};
/**
 * @classdesc
 * Contrôle de dessin.
 *
 * @alias ol.control.Draw
 * @module Draw
 */
declare class Draw extends ToggleContent {
    /**
     * Constructeur du contrôle Draw.
     * @constructor
     * @param {DrawOptions} options Options du constructeur
     * @fires change:active
     */
    constructor(options: DrawOptions);
    icons: {
        Point: string;
        LineString: string;
        Polygon: string;
    } | undefined;
    /**
     * Initialise le contrôle Draw (appelé par le constructeur).
     * @protected
     * @param {DrawOptions} options Options du constructeur
     */
    protected _initialize(options: DrawOptions): void;
    /**
     * Tableau des toggle interactions contenant les interactions de dessin
     * @type {Collection<ToggleInteraction>}
     */
    toggleInteractions: Collection<ToggleInteraction> | undefined;
    modify: boolean | Modify | ModifyingInteraction | undefined;
    source: VectorSource<Feature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>> | undefined;
    layer: VectorLayer<VectorSource<any>, any> | VectorLayer<VectorSource<Feature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>>, Feature<import("ol/geom").Geometry, {
        [x: string]: any;
    }>> | undefined;
    snap: boolean | Snap | undefined;
    /**
     * Interaction de sélection
     * @type {Select}
     */
    select: Select | undefined;
    /**
     * @param {DrawOptions} options Options du constructeur
     * @override
     */
    override _initContainer(options: DrawOptions): void;
    btnGroup: HTMLDivElement | undefined;
    styleDialog: Dialog | StyleDialog | undefined;
    /**
     * Fonction à l'ouverture du dialogue de style.
     * Permet d'initialiser le formulaire
     * @param {Event} e Événement envoyé par l'ouverture du dialog
     * @private
     */
    private onOpenStyleDialog;
    /**
     * @param {DrawOptions} options Options du contrôle
     * @override
     */
    override _initEvents(options: DrawOptions): void;
    activeToggle: any;
    /**
     * Ajoute une propriété flat style sur une entité
     * Les propriétés flat style sont récupérable via
     * `feature.get("flatStyle")` ou via la méthode `getFlatStyle(feature)` du contrôle
     * {@link Draw | Draw}
     *
     * @param {Feature} feature Entité sur laquelle appliquer la propriété
     * @param {String} property Propriété flat style
     * @param {any} value Valeur correspondante
     * @private
     */
    private setFlatStyleProperty;
    /**
     * Récupère le style flat style pour l'appliquer à un formulaire.
     * Cela concatène les valeurs actuelles et, si une entité est donnée en paramètre,
     * les propriétés de l'entité surchargent les valeurs par défaut.
     *
     * @param {Feature} [feature] Entité depuis laquelle récupérer les propriété flatStyle
     * @returns {Object} formulaire de style flat style
     * @public
     */
    public getFlatStyle(feature?: Feature): any;
    /**
     * Fonction par défaut appliquant un style sur des entités.
     *
     * @param {String} property Nom de la propriété flatstyle
     * @param {any} value Valeur correspondante
     * @param {Array<Feature>} features Entités sur lesquelles appliquer le style.
     * @private
     */
    private defaultOnStyle;
    /**
     * Renvoie l'interaction de sélection lié au contrôle
     * @returns {Select} interaction de sélection
     */
    getSelect(): Select;
    /**
     * Récupère l'interaction active si elle existe
     * @returns {ToggleInteraction|undefined} Interaction active (s'il y'en a une)
     */
    getActiveToggle(): ToggleInteraction | undefined;
    /**
     * @param {Map} map Carte à ajouter
     * @override
     */
    override setMap(map: Map): void;
    /**
     * Retourne la source utilisée actuellement
     * @returns {VectorSource} Source actuelle
     */
    getSource(): VectorSource;
    /**
     * Modifie la source pour les interactions de dessins
     * @param {VectorSource} source Source à ajouter
     */
    setSource(source: VectorSource): void;
    /**
     * Ajoute une interaction au contrôle
     * @param {InteractionOptions} options Options pour l'ajout de l'interaction
     */
    addInteraction(options: InteractionOptions): void;
    /**
     * Renvoie le dialogue de style, s'il est ajouté au contrôleur.
     *
     * @returns {StyleDialog|undefined} Dialogue de style
     */
    getStyleDialog(): StyleDialog | undefined;
    /**
     * Définit une couche sur laquelle dessiner.
     * Permet de donner directement une couche au contrôle,
     * plutôt qu'une source seulement.
     *
     * La source de la couche est ensuite mise dans le contrôle.
     *
     * @param {VectorLayer} layer Couche sur laquelle dessiner
     */
    setLayer(layer: VectorLayer): void;
    /**
     * Renvoie la couche de dessin utilisée.
     * Méthode créé pour compatibilité avec contrôle Export.
     *
     * @returns {VectorLayer} Couche de dessin, si elle existe
     */
    getLayer(): VectorLayer;
}
export namespace dsfrDefaultIcons {
    let Point: string;
    let LineString: string;
    let Polygon: string;
}
export namespace defaultIcons {
    let Point_1: string;
    export { Point_1 as Point };
    let LineString_1: string;
    export { LineString_1 as LineString };
    let Polygon_1: string;
    export { Polygon_1 as Polygon };
}
import { Select } from "ol/interaction";
import Feature from "ol/Feature";
import VectorSource from "ol/source/Vector";
import { Modify } from "ol/interaction";
import { Snap } from "ol/interaction";
import Dialog from "../Toggle/Dialog";
import FlatStyleForm from "../StyleDialog/FlatStyleForm";
import DrawInteraction from "ol/interaction/Draw";
import ToggleContent from "../Toggle/ToggleContent";
import ToggleInteraction from "../Toggle/ToggleInteraction";
import Collection from "ol/Collection.js";
import ModifyingInteraction from "../../Interactions/Modifying";
import VectorLayer from "ol/layer/Vector";
import StyleDialog from "../StyleDialog/StyleDialog";
import { Map } from "ol";
//# sourceMappingURL=Draw.d.ts.map