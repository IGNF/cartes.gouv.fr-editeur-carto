export default InputNumber;
export type InputNumberConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Type de l'input
     */
    type?: string | undefined;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Attributs à ajouter sur l'input. Ceux-ci doivent être compatibles avec le .
     */
    attributes?: any;
};
/**
 * @typedef {Object} InputNumberConfig
 * @property {string} label Le label de l'input
 * @property {string} [labelInfo] Info supplémentaire du label (ex: unité)
 * @property {string} property La propriété flat style correspondante
 * @property {string} [type] Type de l'input
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 * @property {Object} [attributes] Attributs à ajouter sur l'input. Ceux-ci doivent être compatibles avec le .
 */
declare class InputNumber extends DefaultInput {
    /**
     * Constructeur du contrôle InputNumber
     * @param {InputNumberConfig} options Options du contrôle
     */
    constructor(options?: InputNumberConfig);
    /**
     * @param {InputNumberConfig} options Options du constructeur
     * @override
     */
    override _initialize(options: InputNumberConfig): void;
    /**
     * @type {Number|null} Nombre retourné par setInterval
     */
    addValue: number | null | undefined;
    /**
     * @type {Number|null} Nombre retourné par setTimeout
     */
    timeout: number | null | undefined;
    /**
     * @type {Boolean} Vrai si l'utilisateur est en train de cliquer sur un bouton
     */
    press: boolean | undefined;
    /**
     * @param {InputNumberConfig} options Options du constructeur
     * @override
     */
    override _initContainer(options: InputNumberConfig): void;
    buttons: HTMLDivElement | undefined;
    up: HTMLButtonElement | undefined;
    down: HTMLButtonElement | undefined;
    /**
     * @param {InputNumberConfig} options Options du constructeur
     * @override
     */
    override _initEvents(options: InputNumberConfig): void;
    /**
     * Gère l'événement mousedown les boutons haut et bas
     * @param {MouseEvent} e Événement de souris
     */
    onButtonMouseDown(e: MouseEvent): void;
    /**
     * Change la valeur de l'input, en l'augmentant ou diminuant;
     * @param {String} up Si vrai, augmente la valeur. Sinon la décroit
     * @param {HTMLInputElement} input Input du contrôle
     */
    changeValue(up: string, input: HTMLInputElement): void;
    /**
     * Gère l'événement mouseleave sur les boutons haut et bas
     */
    onButtonMouseLeave(): void;
    /**
     * Gère l'événement mouseenter sur les boutons haut et bas
     */
    onButtonMouseEnter(): void;
    /**
     * Gère l'événement mouseup sur les boutons haut et bas
     */
    onButtonMouseUp(): void;
}
import DefaultInput from "./DefaultInput.js";
//# sourceMappingURL=InputNumber.d.ts.map