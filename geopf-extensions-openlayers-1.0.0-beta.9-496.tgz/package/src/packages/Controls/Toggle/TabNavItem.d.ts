export default TabNavItem;
/**
 * @classdesc
 * Classe gérant une navigation tertiaire avec onglets.
 *
 * @alias TabNavItem
 * @module TabNavItem
 * @extends {Control}
 */
declare class TabNavItem extends Control {
    /**
     * Constructeur du TabNavItem.
     * @constructor
     * @param {TabNavItemOptions} options Options du constructeur
     */
    constructor(options?: TabNavItemOptions);
    /**
     * @param {TabNavItemOptions} options Options de construction
     */
    _initialize(options: TabNavItemOptions): void;
    tabNavItemClass: string | undefined;
    selectors: {
        OPEN_TAB: string;
        CLOSE_TAB: string;
    } | undefined;
    onOpen: Function | undefined;
    onClose: Function | undefined;
    /**
     * Crée le conteneur principal de la navigation.
     * @protected
     * @param {TabNavItemOptions} options Options de construction
     * @returns {HTMLElement} Élément div de navigation
     */
    protected _initContainer(options: TabNavItemOptions): HTMLElement;
    button: HTMLButtonElement | undefined;
    content: HTMLDivElement | undefined;
    /**
     * @param {TabNavItemOptions} options Options du constructeur
     */
    _initEvents(options: TabNavItemOptions): void;
    /**
     * Retourne l'élément principal de la navigation.
     * @returns {HTMLElement} Élément div de navigation
     */
    getElement(): HTMLElement;
    /**
     * Retourne le bouton de l'item.
     * @returns {HTMLButtonElement} Élément div de navigation
     */
    getButton(): HTMLButtonElement;
    /**
     * Retourne le contenu de l'item.
     *
     * Attention, cela est différent du conteneur dans lequel il se trouve
     * @returns {HTMLElement} Élément div de navigation
     */
    getContent(): HTMLElement;
    /**
     * Affiche le contenu.
     */
    show(): void;
    /**
     * Masque le contenu.
     */
    hide(): void;
    /**
     * Sélectionne ou déselectionne l'item
     * @param {Boolean} bool Vrai si l'élément doit être sélectionné.
     */
    setSelected(bool: boolean): void;
    /**
     * Vérifie si l'élément est sélectionné
     * @return {Boolean} Vrai si l'élément est sélectionné.
     */
    isSelected(): boolean;
}
import Control from "../Control";
//# sourceMappingURL=TabNavItem.d.ts.map