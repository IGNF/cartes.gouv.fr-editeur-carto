export const defaultFlatStyle: {};
export function selectStyle(type: any, featureType: any, iconSrc: any): any;
/** Default flat style
 * @param {String} type Geometry type
 * @param {String} featureType Current feature geometry type or "select"
 * @param {String} iconSrc Icon source for points
 * @returns {Object|Array<Object>} Flat style
 */
export function selectFlatStyle(type: string, featureType: string, iconSrc: string): any | Array<any>;
import { getFlatCoordinates } from "./selectStyle";
export { getFlatCoordinates };
//# sourceMappingURL=selectFlatStyle.d.ts.map